Angka = float (input("Angka kalian:"))

if Angka %2==0 :
    print ("Angka kalian Genap")
else :
    print ("Angka kalian Ganjil")