n =float (input("Berapa nilaimu:"))

if n >=75 :
    print ("kamu lulus")
elif n <75 :
    print ("kamu tidak lulus")
else :
    print ("tidak diketahui")