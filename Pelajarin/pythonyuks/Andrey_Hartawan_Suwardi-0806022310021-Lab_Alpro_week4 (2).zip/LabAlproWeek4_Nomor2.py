#Luas bangun datar segitiga
intergeralas = float(input ("Nilai alas"))
tinggi = float(input("Nilai tinggi"))
kali = float(0.5)
perkalian = intergeralas*tinggi*kali
print ("Hasil Luas Segitiga adalah", perkalian )