#Inputan
N = input ("Siapa nama kamu?")
#Outputan
print ("Halo, perkenalkan nama saya"+N)