#Luas belah ketupat
d1 = 4
sisi = int(input("sisi"))
d2 = (sisi**2-d1**2)**0.5
hasil = 0.5*d1*d2
print ("Hasil luas belah ketupat adalah", hasil)