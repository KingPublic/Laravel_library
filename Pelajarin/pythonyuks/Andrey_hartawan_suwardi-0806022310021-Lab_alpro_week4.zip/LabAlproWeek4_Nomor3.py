#Nilai determinan
A = float (input("nilai A"))
B = float (input("nilai B"))
C = float (input("nilai C"))
D =B*B-2*A*C
print ("Hasil Determinan adalah",D)